/* My Haval — StandBy renderer (ES5 only: must run on old car WebViews).
   StandBy.mount(rootEl, prefs, {preview:bool}) → {update(prefs), destroy()}
   Full page is always 1920×1080; the settings preview scales the same DOM down. */
(function (global) {
  'use strict';

  function pad2(n) { n = String(n); return n.length < 2 ? '0' + n : n; }

  // ---------- Hijri (Umm al-Qura via Intl; silent fallback) ----------
  var hijriOffset = 0;
  function hijri(d, lang) {
    var dd = new Date(d.getTime() + hijriOffset * 86400000);
    return hijriFallback(dd, lang);
  }
  function hijriIntl(d, lang) {
    var loc = (lang === 'ar' ? 'ar-SA' : 'en-US');
    var cals = ['islamic-umalqura', 'islamic-civil', 'islamic'];
    for (var i = 0; i < cals.length; i++) {
      try {
        var f = new Intl.DateTimeFormat(loc + '-u-ca-' + cals[i] + '-nu-latn', { day: 'numeric', month: 'long', year: 'numeric' });
        var s = f.format(d).replace(/\s*(AH|هـ)\s*$/, '');
        if (s && /\d/.test(s)) return s + (lang === 'ar' ? ' هـ' : ' AH');
      } catch (e) { /* next */ }
    }
    return hijriFallback(d, lang);
  }
  // Arithmetic (tabular) Hijri — ±1 day vs Umm al-Qura, only used when Intl lacks the calendar
  function hijriFallback(d, lang) {
    var y = d.getFullYear(), m = d.getMonth() + 1, day = d.getDate();
    var jd = Math.floor((1461 * (y + 4800 + Math.floor((m - 14) / 12))) / 4) + Math.floor((367 * (m - 2 - 12 * Math.floor((m - 14) / 12))) / 12) - Math.floor((3 * Math.floor((y + 4900 + Math.floor((m - 14) / 12)) / 100)) / 4) + day - 32075;
    var l = jd - 1948440 + 10632, n = Math.floor((l - 1) / 10631); l = l - 10631 * n + 354;
    var j = (Math.floor((10985 - l) / 5316)) * (Math.floor((50 * l) / 17719)) + (Math.floor(l / 5670)) * (Math.floor((43 * l) / 15238));
    l = l - (Math.floor((30 - j) / 15)) * (Math.floor((17719 * j) / 50)) - (Math.floor(j / 16)) * (Math.floor((15238 * j) / 43)) + 29;
    var hm = Math.floor((24 * l) / 709), hd = l - Math.floor((709 * hm) / 24), hy = 30 * n + j - 30;
    var ar = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];
    var en = ['Muharram', 'Safar', 'Rabi I', 'Rabi II', 'Jumada I', 'Jumada II', 'Rajab', 'Shaban', 'Ramadan', 'Shawwal', 'Dhu al-Qadah', 'Dhu al-Hijjah'];
    return hd + ' ' + (lang === 'ar' ? ar : en)[hm - 1] + ' ' + hy + (lang === 'ar' ? ' هـ' : ' AH');
  }

  // ---------- Prayer times (Umm al-Qura: Fajr 18.5°, Isha = Maghrib + 90 min) ----------
  function prayerTimes(d, lat, lng, tz) {
    var rad = Math.PI / 180, deg = 180 / Math.PI;
    var y = d.getFullYear(), m = d.getMonth() + 1, day = d.getDate();
    if (m <= 2) { y -= 1; m += 12; }
    var A = Math.floor(y / 100), B = 2 - A + Math.floor(A / 4);
    var jd = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + day + B - 1524.5;
    var D = jd - 2451545.0;
    var g = (357.529 + 0.98560028 * D) % 360, q = (280.459 + 0.98564736 * D) % 360;
    var L = (q + 1.915 * Math.sin(g * rad) + 0.020 * Math.sin(2 * g * rad)) % 360;
    var e = 23.439 - 0.00000036 * D;
    var RA = Math.atan2(Math.cos(e * rad) * Math.sin(L * rad), Math.cos(L * rad)) * deg / 15;
    var decl = Math.asin(Math.sin(e * rad) * Math.sin(L * rad)) * deg;
    var eqt = q / 15 - ((RA % 24) + 24) % 24;
    var dhuhr = 12 + tz - lng / 15 - eqt;
    function ha(angle) {
      var v = (-Math.sin(angle * rad) - Math.sin(lat * rad) * Math.sin(decl * rad)) / (Math.cos(lat * rad) * Math.cos(decl * rad));
      return Math.acos(Math.max(-1, Math.min(1, v))) * deg / 15;
    }
    var asrAngle = -Math.atan(1 / (1 + Math.tan(Math.abs(lat - decl) * rad))) * deg;
    var t = { fajr: dhuhr - ha(18.5), sunrise: dhuhr - ha(0.833), dhuhr: dhuhr, asr: dhuhr + ha(asrAngle), maghrib: dhuhr + ha(0.833) };
    t.isha = t.maghrib + 1.5;
    return t;
  }
  function fmtH(h, h12) {
    h = ((h % 24) + 24) % 24; var hh = Math.floor(h), mm = Math.round((h - hh) * 60); if (mm === 60) { hh++; mm = 0; }
    if (h12) { var am = hh < 12; var x = hh % 12 || 12; return x + ':' + pad2(mm) + (am ? ' AM' : ' PM'); }
    return pad2(hh) + ':' + pad2(mm);
  }

  var T = {
    ar: { fajr: 'الفجر', sunrise: 'الشروق', dhuhr: 'الظهر', asr: 'العصر', maghrib: 'المغرب', isha: 'العشاء',
          days: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
          months: ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'], touch: 'المس الشاشة للعودة' },
    en: { fajr: 'Fajr', sunrise: 'Sunrise', dhuhr: 'Dhuhr', asr: 'Asr', maghrib: 'Maghrib', isha: 'Isha',
          days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
          months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'], touch: 'Touch the screen to return' }
  };

  // All sizes are px on a 1920×1080 canvas (the preview scales the whole box)
  var CSS = '' +
  '.sb{position:absolute;left:0;top:0;width:1920px;height:1080px;overflow:hidden;background:#000;color:#fff;font-family:"Roboto","Noto Sans Arabic",sans-serif;-webkit-user-select:none;user-select:none}' +
  '.sb *{box-sizing:border-box}' +
  '.sb .bg{position:absolute;left:0;top:0;width:1920px;height:1080px;background-size:100% 100%}' +
  '.sb .wp{position:absolute;left:0;top:0;width:100%;height:100%;background-size:cover;background-position:center}' +
  '.sb .shade{position:absolute;left:0;top:0;width:100%;height:100%;background:-webkit-linear-gradient(top,rgba(0,0,0,.25),rgba(0,0,0,.55));background:linear-gradient(180deg,rgba(0,0,0,.25),rgba(0,0,0,.55))}' +
  '.sb .glass{position:absolute;left:0;width:100%;top:270px;text-align:center}' +
  '.sb .time{font-size:240px;line-height:1;letter-spacing:-4px;font-weight:300;text-shadow:0 0 40px rgba(0,0,0,.6)}' +
  '.sb .ampm{font-size:44px;opacity:.7;margin-left:12px;vertical-align:top;line-height:2}' +
  '.sb .date{font-size:46px;opacity:.92;margin-top:18px}' +
  '.sb .hijri{font-size:36px;opacity:.7;margin-top:8px}' +
  '.sb .greet{font-size:52px;font-weight:300;color:#E8923A;margin-top:34px;letter-spacing:.5px}' +
  '.sb .temp{position:absolute;left:56px;top:28px;font-size:40px;font-weight:300;opacity:.8}' +
  '.sb.rtl .temp{left:auto;right:56px}' +
  '.sb .cal .greet{font-size:44px;margin-top:24px}' +
  '.sb .analog{position:absolute;left:230px;top:180px;width:720px;height:720px}' +
  '.sb .analog svg{width:720px;height:720px}' +
  '.sb .cal{position:absolute;right:200px;top:230px;text-align:right;width:800px}' +
  '.sb .cal .day{font-size:64px;font-weight:300;opacity:.95}' +
  '.sb .cal .big{font-size:170px;line-height:1;font-weight:300;color:#E8923A}' +
  '.sb .cal .mon{font-size:54px;opacity:.9}' +
  '.sb .cal .hij{font-size:36px;opacity:.65;margin-top:10px}' +
  '.sb .cal .t{font-size:76px;margin-top:30px;font-weight:300}' +
  '.sb.rtl .analog{left:auto;right:230px}' +
  '.sb.rtl .cal{right:auto;left:200px;text-align:left}' +
  '.sb .prayer{position:absolute;left:0;width:100%;bottom:44px;text-align:center;font-size:28px;opacity:.85}' +
  '.sb .prayer div{display:inline-block;width:200px;text-align:center;margin:0 20px}' +
  '.sb .prayer b{display:block;font-weight:400;font-size:34px;margin-top:4px}' +
  '.sb .prayer .nx{color:#E8923A}.sb .prayer .nx b{color:#fff}' +
  '.sb .hint{position:absolute;right:56px;top:32px;font-size:26px;opacity:.35;letter-spacing:1px}' +
  '.sb.rtl .hint{right:auto;left:56px}' +
  '.sb .dot{position:absolute;width:6px;height:6px;border-radius:50%;background:#fff}' +
  /* ---- shared controls layer (volume + exit), design-independent ---- */
  /* no opacity on the container (avoids nested-opacity washout); children carry their own alpha */
  '.sb .vol{position:absolute;right:58px;top:300px;width:92px;height:480px}' +
  '.sb .vol .track{position:absolute;right:18px;top:0;width:8px;height:480px;border-radius:4px;background:rgba(255,255,255,.22);-webkit-transition:box-shadow .4s;transition:box-shadow .4s}' +
  '.sb .vol.on .track{box-shadow:0 0 26px 2px rgba(232,146,58,.55)}' +
  '.sb .vol .fill{position:absolute;left:0;bottom:0;width:100%;height:0;border-radius:4px;background:#E8923A;opacity:.5;-webkit-transition:opacity .4s;transition:opacity .4s}' +
  '.sb .vol.on .fill{opacity:1}' +
  '.sb .vol .knob{position:absolute;left:-7px;bottom:0;width:22px;height:22px;margin-bottom:-11px;border-radius:50%;background:#fff4e4;opacity:0;-webkit-transition:opacity .4s;transition:opacity .4s}' +
  '.sb .vol.on .knob{opacity:1}' +
  '.sb .vol .num{position:absolute;right:46px;top:188px;width:150px;text-align:right;font-size:78px;font-weight:200;opacity:0;-webkit-transition:opacity .4s;transition:opacity .4s;text-shadow:0 0 18px rgba(0,0,0,.6)}' +
  '.sb .vol.on .num{opacity:.95}' +
  '.sb .exit{position:absolute;top:80px;right:46px;width:66px;height:66px;border-radius:50%;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.28);opacity:.5;-webkit-transition:opacity .4s,background .4s;transition:opacity .4s,background .4s}' +
  '.sb.rtl .exit{right:auto;left:46px}' +
  '.sb .exit.on{opacity:1;background:rgba(255,255,255,.16)}' +
  '.sb .exit i{position:absolute;left:32px;top:19px;width:2px;height:28px;background:rgba(255,255,255,.8)}' +
  '.sb .exit i.a{-webkit-transform:rotate(45deg);transform:rotate(45deg)}' +
  '.sb .exit i.b{-webkit-transform:rotate(-45deg);transform:rotate(-45deg)}';

  function analogSVG() {
    var ticks = '';
    for (var i = 0; i < 60; i++) {
      var a = i * 6 * Math.PI / 180, maj = i % 5 === 0, r1 = maj ? 86 : 90, r2 = 94;
      ticks += '<line x1="' + (100 + r1 * Math.sin(a)) + '" y1="' + (100 - r1 * Math.cos(a)) + '" x2="' + (100 + r2 * Math.sin(a)) + '" y2="' + (100 - r2 * Math.cos(a)) + '" stroke="' + (maj ? '#fff' : 'rgba(255,255,255,.35)') + '" stroke-width="' + (maj ? 2 : 1) + '" stroke-linecap="round"/>';
    }
    return '<svg viewBox="0 0 200 200" width="720" height="720">' +
      '<circle cx="100" cy="100" r="97" fill="rgba(0,0,0,.35)" stroke="rgba(255,255,255,.18)" stroke-width="1"/>' + ticks +
      '<g class="hh"><line x1="100" y1="100" x2="100" y2="52" stroke="#fff" stroke-width="5" stroke-linecap="round"/></g>' +
      '<g class="mm"><line x1="100" y1="100" x2="100" y2="30" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/></g>' +
      '<circle cx="100" cy="100" r="4" fill="#E8923A"/></svg>';
  }

  var styleInjected = false;
  function mount(root, prefs, opts) {
    opts = opts || {};
    if (!styleInjected) { var st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st); styleInjected = true; }
    var el = document.createElement('div'); el.className = 'sb'; root.appendChild(el);
    var timer = null, cfg = {};
    var N = global.Native || null;
    var volMax = 30, volDrag = false, volFade = null;

    function lang() { if (cfg.lang === 'ar' || cfg.lang === 'en') return cfg.lang; var n = ''; try { n = navigator.language || ''; } catch (e) {} return n.indexOf('ar') === 0 ? 'ar' : 'en'; }
    function h12() { return cfg.clock12 === '1'; }
    function q(sel) { return el.querySelector(sel); }
    function setText(sel, t) { var n = q(sel); if (n) n.textContent = t; }

    // ---- shared controls: media volume (AudioManager) + exit button ----
    function volLevel() { try { if (N && N.volGet) return N.volGet(); } catch (e) {} return 0; }
    function volSetUI(lv) {
      var pct = volMax > 0 ? Math.max(0, Math.min(100, lv * 100 / volMax)) : 0;
      var f = q('#vfill'), k = q('#vknob'), n = q('#vnum');
      if (f) f.style.height = pct + '%';
      if (k) k.style.bottom = pct + '%';
      if (n) n.textContent = String(lv);
    }
    function volRefresh() { if (!volDrag) volSetUI(volLevel()); }
    function volGlow(on) {
      var v = q('#vol'); if (!v) return;
      if (on) { if (volFade) { clearTimeout(volFade); volFade = null; } v.className = 'vol on'; }
      else { if (volFade) clearTimeout(volFade); volFade = setTimeout(function () { var vv = q('#vol'); if (vv) vv.className = 'vol'; }, 1500); }
    }
    function volFromY(ev) {
      var t = q('#vol .track'); if (!t) return null;
      var r = t.getBoundingClientRect();
      var y = (ev.touches && ev.touches[0]) ? ev.touches[0].clientY : ev.clientY;
      var frac = 1 - ((y - r.top) / r.height); frac = frac < 0 ? 0 : (frac > 1 ? 1 : frac);
      return Math.round(frac * volMax);
    }
    function volApply(lv) { try { if (N && N.volSet) N.volSet(lv); } catch (e) {} volSetUI(lv); }
    function doHide() { try { if (N && N.hide) N.hide(); } catch (e) {} }
    function wireControls() {
      var v = q('#vol');
      if (v) {
        try { if (N && N.volMax) { var m = N.volMax(); if (m > 0) volMax = m; } } catch (e) {}
        volSetUI(volLevel());
        var down = function (ev) { volDrag = true; volGlow(true); var lv = volFromY(ev); if (lv != null) volApply(lv); if (ev.preventDefault) ev.preventDefault(); ev.stopPropagation(); };
        var move = function (ev) { if (!volDrag) return; var lv = volFromY(ev); if (lv != null) volApply(lv); if (ev.preventDefault) ev.preventDefault(); ev.stopPropagation(); };
        var up = function (ev) { if (!volDrag) return; volDrag = false; volGlow(false); if (ev && ev.stopPropagation) ev.stopPropagation(); };
        v.addEventListener('touchstart', down, false);
        v.addEventListener('touchmove', move, false);
        v.addEventListener('touchend', up, false);
        v.addEventListener('touchcancel', up, false);
        v.addEventListener('mousedown', function (e) { down(e); var mm = function (e2) { move(e2); }, mu = function () { up(null); document.removeEventListener('mousemove', mm); document.removeEventListener('mouseup', mu); }; document.addEventListener('mousemove', mm); document.addEventListener('mouseup', mu); }, false);
        v.addEventListener('click', function (e) { e.stopPropagation(); }, false);
      }
      var x = q('#sbexit');
      if (x) {
        var glow = function () { x.className = 'exit on'; };
        x.addEventListener('touchstart', function (e) { glow(); e.stopPropagation(); }, false);
        x.addEventListener('touchend', function (e) { if (e.preventDefault) e.preventDefault(); e.stopPropagation(); doHide(); }, false);
        x.addEventListener('mousedown', function (e) { glow(); e.stopPropagation(); }, false);
        x.addEventListener('click', function (e) { e.stopPropagation(); doHide(); }, false);
      }
    }

    function build() {
      var Lg = lang(); var isAr = Lg === 'ar';
      el.className = 'sb' + (isAr ? ' rtl' : ''); el.setAttribute('dir', isAr ? 'rtl' : 'ltr');
      var design = cfg.sb_design || 'glass';
      var bg = cfg.sb_bg || 'cluster';
      if (design === 'photo') { design = 'glass'; bg = 'photo'; }
      var html = '';
      if (bg === 'photo') { html += '<div class="wp" id="wp"></div><div class="shade"></div>'; }
      else if (bg === 'cluster' || bg === 'glow') { var bgf = (bg === 'glow') ? 'bg_glow.jpg' : 'bg_cluster.jpg'; html += '<div class="bg" style="background-image:url(' + (global.SB_BASE || '') + bgf + ')"></div>'; }
      else { for (var i = 0; i < 18; i++) html += '<div class="dot" style="left:' + ((i * 37 + 11) % 100) * 19.2 + 'px;top:' + ((i * 53 + 7) % 100) * 10.8 + 'px;opacity:' + (0.15 + (i % 4) * 0.1) + '"></div>'; }
      if (design === 'analog') {
        html += '<div class="analog">' + analogSVG() + '</div><div class="cal"><div class="day" id="day"></div><div class="big" id="dd"></div><div class="mon" id="mon"></div><div class="hij" id="hij"></div><div class="t" id="t2"></div><div class="greet" id="greet"></div></div>';
      } else {
        html += '<div class="glass"><div class="time"><span id="t"></span><span class="ampm" id="ap"></span></div><div class="date" id="date"></div><div class="hijri" id="hij"></div><div class="greet" id="greet"></div></div>';
      }
      if (cfg.sb_prayer !== '0') html += '<div class="prayer" id="pr"></div>';
      if (cfg.sb_temp !== '0' && cfg.car_temp) html += '<div class="temp" id="temp"></div>';
      if (cfg.sb_vol !== '0') html += '<div class="vol" id="vol"><div class="num" id="vnum"></div><div class="track"><div class="fill" id="vfill"></div><div class="knob" id="vknob"></div></div></div>';
      if ((cfg.sb_exit || 'btn') !== 'tap') html += '<div class="exit" id="sbexit"><i class="a"></i><i class="b"></i></div>';
      el.innerHTML = html;
      if (bg === 'photo') {
        var wp = q('#wp'); var src = cfg.sb_wallpaper_data || '';
        if (wp && src) wp.style.backgroundImage = 'url("' + src + '")';
        else if (wp) wp.style.background = '-webkit-radial-gradient(30% 40%, ellipse, #1b2838, #000 70%)';
      }
      if (!opts.preview) wireControls();
      else { var pf = q('#vfill'); if (pf) pf.style.height = '62%'; }
      tick();
    }

    function tick() {
      var d = new Date(), Lg = lang(), tt = T[Lg];
      var dateStr = tt.days[d.getDay()] + (Lg === 'ar' ? '، ' : ', ') + d.getDate() + ' ' + tt.months[d.getMonth()] + ' ' + d.getFullYear();
      var hij = ''; if (cfg.sb_hijri !== '0') { try { hij = hijri(d, Lg); } catch (e) { hij = ''; } }
      if ((cfg.sb_design || 'glass') === 'analog') {
        var hh = d.getHours() % 12, mm = d.getMinutes(), ss = d.getSeconds();
        var gh = q('.hh'), gm = q('.mm');
        if (gh) gh.setAttribute('transform', 'rotate(' + (hh * 30 + mm * 0.5) + ' 100 100)');
        if (gm) gm.setAttribute('transform', 'rotate(' + (mm * 6 + ss * 0.1) + ' 100 100)');
        setText('#day', tt.days[d.getDay()]); setText('#dd', String(d.getDate()));
        setText('#mon', tt.months[d.getMonth()] + ' ' + d.getFullYear()); setText('#hij', hij);
        setText('#t2', fmtH(d.getHours() + d.getMinutes() / 60, h12()));
      } else {
        var t = fmtH(d.getHours() + d.getMinutes() / 60, h12());
        if (h12()) { setText('#t', t.slice(0, -3)); setText('#ap', t.slice(-2)); } else { setText('#t', t); setText('#ap', ''); }
        setText('#date', dateStr); setText('#hij', hij);
      }
      var gr = q('#greet');
      if (gr) { var hr = d.getHours(); var am = hr >= 4 && hr < 12; var txt = cfg.sb_greet === '0' ? '' : (am ? (cfg.sb_greet_am || '') : (cfg.sb_greet_pm || '')); gr.textContent = txt; gr.style.display = txt ? '' : 'none'; }
      var tp = q('#temp'); if (tp) { var tv = parseFloat(cfg.car_temp); tp.textContent = isNaN(tv) ? '' : Math.round(tv) + '°'; }
      var pr = q('#pr');
      if (pr) {
        try {
          var lat = parseFloat(cfg.lat || '24.7136'), lng = parseFloat(cfg.lng || '46.6753'), tz = parseFloat(cfg.tz || '3');
          var pt = prayerTimes(d, lat, lng, tz);
          var now = d.getHours() + d.getMinutes() / 60 + d.getSeconds() / 3600;
          var order = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'], next = 'fajr';
          for (var i = 0; i < order.length; i++) { if (order[i] !== 'sunrise' && pt[order[i]] > now) { next = order[i]; break; } }
          var out = '';
          for (var k = 0; k < order.length; k++) out += '<div class="' + (order[k] === next ? 'nx' : '') + '">' + tt[order[k]] + '<b>' + fmtH(pt[order[k]], h12()) + '</b></div>';
          pr.innerHTML = out;
        } catch (e) { pr.innerHTML = ''; }
      }
      if (!opts.preview && cfg.sb_vol !== '0') volRefresh();
    }

    function update(p) {
      var prev = cfg; cfg = {}; p = p || {}; for (var k in p) cfg[k] = p[k]; hijriOffset = (cfg.hijri_adj === undefined ? -1 : (parseInt(cfg.hijri_adj, 10) || 0));
      var rebuild = !el.innerHTML || prev.sb_design !== cfg.sb_design || prev.lang !== cfg.lang || prev.sb_prayer !== cfg.sb_prayer || prev.sb_bg !== cfg.sb_bg || prev.sb_temp !== cfg.sb_temp || (!!prev.car_temp) !== (!!cfg.car_temp) || prev.sb_wallpaper_data !== cfg.sb_wallpaper_data || prev.sb_vol !== cfg.sb_vol || prev.sb_exit !== cfg.sb_exit;
      if (rebuild) build(); else tick();
    }
    update(prefs);
    try { if (N && N.log) N.log('sb build=ui13 controls preview=' + (opts.preview ? 1 : 0) + ' vol=' + (cfg.sb_vol !== '0' ? 1 : 0) + ' exit=' + ((cfg.sb_exit || 'btn') !== 'tap' ? 1 : 0)); } catch (e) {}
    timer = setInterval(tick, 1000);
    return { update: update, destroy: function () { clearInterval(timer); if (el.parentNode) el.parentNode.removeChild(el); } };
  }

  global.StandBy = { mount: mount, hijri: hijri, prayerTimes: prayerTimes, setHijriOffset: function (n) { hijriOffset = parseInt(n, 10) || 0; } };
})(window);
